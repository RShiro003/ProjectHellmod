---
title: nodes-note-manual
---

node is an [Input Manager](https://docs.unity3d.com/Manual/class-InputManager.html) node. For more information about how to use the Input Manager with Visual Scripting, see [Capture user input in an application](../../vs-capture-player-input.md). 
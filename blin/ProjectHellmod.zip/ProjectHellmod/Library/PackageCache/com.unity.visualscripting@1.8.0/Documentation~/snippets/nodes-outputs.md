---
title: nodes-outputs
---

node has the following output ports:
---
title: open-graph-inspector
---

Select **Graph Inspector** (![The Graph Inspector icon](../images/vs-graph-inspector-icon.png)) from the toolbar.
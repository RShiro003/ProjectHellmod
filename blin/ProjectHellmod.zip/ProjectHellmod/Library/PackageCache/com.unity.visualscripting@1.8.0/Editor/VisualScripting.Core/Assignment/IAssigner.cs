namespace Unity.VisualScripting
{
    public interface IAssigner
    {
        void ValueChanged();
    }
}

namespace Unity.VisualScripting
{
    public interface IMacroDescription : IDescription { }
}
